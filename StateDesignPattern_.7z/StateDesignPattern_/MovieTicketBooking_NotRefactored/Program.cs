﻿using System;

namespace MovieTicketBooking_NotRefactored
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
